<?php

//--- GET THE ROOM INFORMATION PASSED FROM OTHER PAGE
$roomNumber = isset($_GET['roomNumber']) ? intval($_GET['roomNumber']) : 1;
$amenityNumber = isset($_GET['amenityNumber']) ? intval($_GET['amenityNumber']) : -1;

//--- THE MAP OF ALL AVAILABLE AMENITIES LISTED
$amenityMap = [
    1 => 'Mini Bar',
    2 => 'Extra Bed',
    3 => 'Sea View',
    4 => 'Room Service',
    5 => 'Breakfast Included'
];

//--- THE MAP OF ALL DATA AVAILABLE IN THE ROOM DATABASE TABLE (DEFAULT DATA, NO DATABASE YET)
$roomData = [
    'title' => "Room $roomNumber",
    'description' => "A comfortable room with modern amenity, perfect for relaxation.",
    'price' => 150, // price per night
    'images' => [
        "../design/images/room{$roomNumber}_1.jpg",
        "../design/images/room{$roomNumber}_2.jpg",
        "../design/images/room{$roomNumber}_3.jpg"
    ],
    'free_amenity' => ['Wi-Fi', 'Air Conditioning', 'Flat-screen TV', 'Bathroom essentials'],
    'additional_amenity' => ['Mini Bar', 'Extra Bed', 'Sea View', 'Room Service']
];

//--- WHEN THERES ADDED AMENITIES BY THE CLIENT THEN ADD IT
if ($amenityNumber !== -1 && isset($amenityMap[$amenityNumber]))
{
    $selectedAmenity = $amenityMap[$amenityNumber];

    //--- THIS PREVENT ANY DUPLICATE AMENITIES ADDED BY THE CLIENT
    if (!in_array($selectedAmenity, $roomData['additional_amenity']))
    {
        $roomData['additional_amenity'][] = $selectedAmenity;
    }
}

//--- WHEN THE ADD AMENITIES IS CLICKED, REDIRECT IT TO THE AMENITIES PAGE
if (isset($_POST['add-amenity']))
{
    $clickedRoom = $_POST['roomNumber'];
    header(
        "Location: amenity.php?roomNumber=" . $clickedRoom
    );
    exit;
}

//--- HEADER OF THE HOME PAGE
include("header.html");

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?= $roomData['title'] ?> Details</title>
    <link rel="stylesheet" href="../design/roomDetailStyle.css">
</head>

<body>
    <h1><?= $roomData['title'] ?></h1>

    <!-- Room Images -->
    <div class="room-images">
        <?php foreach ($roomData['images'] as $img): ?>
            <img src="<?= $img ?>" alt="Room Image">
        <?php endforeach; ?>
    </div>

    <!-- Room Details -->
    <div class="room-details">
        <h2>Description</h2>
        <p><?= $roomData['description'] ?></p>

        <h2>Price</h2>
        <p>$<?= number_format($roomData['price'], 2) ?> per night</p>

        <!-- FREE AMENITIES LISTED -->
        <h2>Free Amenities</h2>
        <ul>
            <?php foreach ($roomData['free_amenity'] as $amenity): ?>
                <li><?= $amenity ?></li>
            <?php endforeach; ?>
        </ul>

        <!-- CLIENT ADDS ON AMENITIES LISTED -->
        <h2>Additional amenity</h2>
        <ul>
            <?php foreach ($roomData['additional_amenity'] as $amenity): ?>
                <li><?= $amenity ?></li>
            <?php endforeach; ?>
        </ul>

        <div class="buttons">
            <form method="POST" style="display:inline;">
                <input type="hidden" name="roomNumber" value="<?= $roomNumber ?>">
                <button type="submit" name="add-amenity" class="add-amenity">Add Amenity</button>
            </form>

            <form method="POST" style="display:inline;">
                <input type="hidden" name="roomNumber" value="<?= $roomNumber ?>">
                <button type="submit" class="btn-book">Book Now</button>
            </form>
        </div>
    </div>

</body>
</html>

<!-- FOOTER OF THE HOME PAGE -->
<?php include("footer.html"); ?>