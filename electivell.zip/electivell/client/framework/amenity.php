<!-- HEADER OF THE HOME PAGE -->
<?php include("header.html"); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>amenity</title>
    <link rel="stylesheet" href="../design/amenityStyle.css">
</head>

<body>

    <!-- SCROLLABLE AMENITY IN THE PAGE -->
    <div class="amenity-scroll">

        <?php
            for ($i = 1; $i <= 10; $i++)
            {
                renderAmenityCard($i);
            }
        ?>

    </div>
</body>
</html>

<!-- PHP FUNCTION LIST -->
<?php

//--- FUNCTION FOR EVERY AMENITY CARD
function renderAmenityCard(int $amenityNumber)
{
    //--- WHEN VIEW DETAILS IS CLICKED, REDIRECT TO ROOM DETAILS WITH AMENITY
    if (isset($_POST['view-details']))
    {
        $clickedAmenity = $_POST['amenityNumber'];
        $roomNumber = $_POST['roomNumber'];
        
        header(
            "Location: amenityDetails.php?roomNumber=" . $roomNumber .
            "&amenityNumber=" . $clickedAmenity
        );
        exit;
    }
    ?>

    <div class="amenity-card">
        <div class="room-images">
            <img src="../design/images/amenity<?= $amenityNumber ?>_1.jpg" alt="Amenity image">
            <img src="../design/images/amenity<?= $amenityNumber ?>_2.jpg" alt="Amenity image">
            <img src="../design/images/amenity<?= $amenityNumber ?>_3.jpg" alt="Amenity image">
        </div>

        <h3>Amenity <?= $amenityNumber ?></h3>

        <p class="amenity-desc">
            Enhance your stay with this premium amenity.
        </p>

        <form method="POST">
            <input type="hidden" name="amenityNumber" value="<?= $amenityNumber ?>">
            <input type="hidden" name="roomNumber" value="<?= $_GET['roomNumber'] ?? -1 ?>">
            <button type="submit" name="view-details" class="room-btn"> View Details </button>
        </form>
    </div>

    <?php
}
?>

<!-- FOOTER OF THE HOME PAGE -->
<?php include("footer.html"); ?>
